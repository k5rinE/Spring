package com.teamtwo.model;

public class PurchaseDTO {

  private int productId;
  private int productQty;
  
  public int getProductId() {
    return productId;
  }
  
  public void setProductId(int productId) {
    this.productId = productId;
  }
  
  public int getProductQty() {
    return productQty;
  }
  
  public void setProductQty(int productQty) {
    this.productQty = productQty;
  }
  
}

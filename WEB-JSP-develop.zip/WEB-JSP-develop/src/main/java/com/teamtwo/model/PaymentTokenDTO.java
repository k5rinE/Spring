package com.teamtwo.model;

public class PaymentTokenDTO {

  private String access_token;

  public String getAccessToken() {
    return access_token;
  }

  public void setAccessToken(String access_token) {
    this.access_token = access_token;
  }
  
}

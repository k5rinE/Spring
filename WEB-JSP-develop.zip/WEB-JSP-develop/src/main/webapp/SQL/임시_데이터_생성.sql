-- 유저 데이터 삽입
INSERT INTO T_customer VALUES (1, 'jdoe', 'password123', 'Javan Rhino', 'javanrhino@example.com', '01012345678', 'M', TO_DATE('1990-05-15', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (2, 'asmith', 'secureP@ssw0rd', 'Amur Leopard', 'amurleopard@example.com', '01023456789', 'F', TO_DATE('1985-08-22', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (3, 'bjones', 'myp@ssw0rd', 'Vaquita', 'vaquita@example.com', '01034567890', 'M', TO_DATE('1992-11-30', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (4, 'cwhite', 'passw0rd!', 'Kakapo', 'kakapo@example.com', '01045678901', 'F', TO_DATE('1988-03-10', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (5, 'dblack', '1234abcd', 'Saola', 'saola@example.com', '01056789012', 'M', TO_DATE('1995-07-25', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (6, 'egreen', 'password2024', 'Sumatran Orangutan', 'sumatranorangutan@example.com', '01067890123', 'F', TO_DATE('1991-01-12', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (7, 'fwhite', 'simplepass', 'Northern Bald Ibis', 'northernbaldibis@example.com', '01078901234', 'M', TO_DATE('1989-12-08', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (8, 'gblack', 'p@ssw0rd!', 'Yangtze Giant Softshell Turtle', 'yangtzegiants@example.com', '01089012345', 'F', TO_DATE('1994-09-19', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (9, 'hgray', 'qwerty123', 'Psychedelic Rock Gecko', 'psychedelicrockgec@example.com', '01090123456', 'M', TO_DATE('1987-06-30', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (10, 'ijones', '1234abcd!', 'Mountain Gorilla', 'mountaingorilla@example.com', '01001234567', 'F', TO_DATE('1993-03-15', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (11, 'kgreen', 'greenpass1', 'Wollemi Pine', 'wollemi@example.com', '01012345671', 'F', TO_DATE('1983-11-30', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (12, 'lblue', 'blue1234', 'Rafflesia arnoldii', 'rafflesia@example.com', '01023456782', 'M', TO_DATE('1990-07-22', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (13, 'mgray', 'gray2024', 'Baobab', 'baobab@example.com', '01034567893', 'F', TO_DATE('1985-04-15', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (14, 'nblack', 'blackpass', 'Amorphophallus titanium', 'amorphophallus@example.com', '01045678904', 'M', TO_DATE('1992-01-18', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (15, 'obrown', 'brownpass', 'Cycad', 'cycad@example.com', '01056789015', 'F', TO_DATE('1988-10-04', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (16, 'pwhite', 'white2024', 'Hoodia gordonii', 'hoodia@example.com', '01067890126', 'M', TO_DATE('1993-05-17', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (17, 'qgreen', 'greenpass2024', 'Welwitschia', 'welwitschia@example.com', '01078901237', 'F', TO_DATE('1987-08-25', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (18, 'rblue', 'blue2024', 'Titan Arum', 'titanarum@example.com', '01089012348', 'M', TO_DATE('1994-03-05', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (19, 'sgray', 'graypass1', 'Jellyfish Tree', 'jellyfishtree@example.com', '01090123459', 'F', TO_DATE('1991-06-12', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (20, 'tblack', 'black2024', 'African Violet', 'africanviolet@example.com', '01001234580', 'M', TO_DATE('1995-09-09', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (21, 'ubrown', 'brown2024', 'Encephalartos woodii', 'encephalartos@example.com', '01012345682', 'F', TO_DATE('1982-02-26', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (22, 'vgreen', 'greenpass2025', 'Edelweiss', 'edelweiss@example.com', '01023456783', 'M', TO_DATE('1992-04-10', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (23, 'wgray', 'gray1234', 'Saguaro Cactus', 'saguaro@example.com', '01034567894', 'F', TO_DATE('1986-11-21', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (24, 'xblack', 'blackpass2024', 'Ghost Orchid', 'ghostorchid@example.com', '01045678905', 'M', TO_DATE('1989-12-30', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (25, 'yblue', 'blue2025', 'Monkey Puzzle Tree', 'monkeypuzzletree@example.com', '01056789016', 'F', TO_DATE('1984-05-15', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (26, 'zgreen', 'greenpass2025', 'Rafflesia consueloae', 'rafflesia2@example.com', '01067890127', 'M', TO_DATE('1990-09-12', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (27, 'aorange', 'orange2024', 'Dwarf Umbrella Tree', 'dwarfumbrellatree@example.com', '01078901238', 'F', TO_DATE('1987-07-19', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (28, 'bblack', 'black2025', 'Dodo Tree', 'dodotree@example.com', '01089012349', 'M', TO_DATE('1993-12-25', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (29, 'cgray', 'graypass2025', 'Titanopsis calcarea', 'titanopsis@example.com', '01090123460', 'F', TO_DATE('1991-11-11', 'YYYY-MM-DD'), SYSDATE, '');
INSERT INTO T_customer VALUES (30, 'dblue', 'bluepass2024', 'Creeping Fig', 'creepingfig@example.com', '01001234581', 'M', TO_DATE('1986-10-08', 'YYYY-MM-DD'), SYSDATE, '');


-- 배송지 데이터 삽입
INSERT INTO T_shipping_address VALUES (1, '123 Elm Street, New York, USA', 'Y', 1);   -- 유저 1
INSERT INTO T_shipping_address VALUES (2, '456 Oak Avenue, Toronto, Canada', 'N', 1);  -- 유저 1
INSERT INTO T_shipping_address VALUES (3, '789 Pine Road, London, UK', 'N', 2);        -- 유저 2
INSERT INTO T_shipping_address VALUES (4, '101 Maple Lane, Berlin, Germany', 'N', 2);   -- 유저 2
INSERT INTO T_shipping_address VALUES (5, '202 Birch Blvd, Sydney, Australia', 'N', 2); -- 유저 2
INSERT INTO T_shipping_address VALUES (6, '303 Cedar Street, Tokyo, Japan', 'Y', 2);    -- 유저 2
INSERT INTO T_shipping_address VALUES (7, '404 Willow Way, Paris, France', 'Y', 3);     -- 유저 3
INSERT INTO T_shipping_address VALUES (8, '505 Ash Drive, Rome, Italy', 'Y', 4);        -- 유저 4
INSERT INTO T_shipping_address VALUES (9, '606 Cherry Circle, Madrid, Spain', 'Y', 5);  -- 유저 5
INSERT INTO T_shipping_address VALUES (10, '707 Redwood Path, São Paulo, Brazil', 'Y', 6); -- 유저 6
INSERT INTO T_shipping_address VALUES (11, '808 Spruce Court, Cape Town, South Africa', 'N', 6); -- 유저 6
INSERT INTO T_shipping_address VALUES (12, '909 Fir Terrace, Seoul, South Korea', 'Y', 7); -- 유저 7
INSERT INTO T_shipping_address VALUES (13, '010 Willow Avenue, Moscow, Russia', 'N', 7); -- 유저 7
INSERT INTO T_shipping_address VALUES (14, '121 Maple Road, Istanbul, Turkey', 'Y', 8);   -- 유저 8
INSERT INTO T_shipping_address VALUES (15, '232 Pine Street, Dubai, UAE', 'Y', 9);       -- 유저 9
INSERT INTO T_shipping_address VALUES (16, '343 Oak Drive, Mumbai, India', 'Y', 10);     -- 유저 10
INSERT INTO T_shipping_address VALUES (17, '454 Elm Court, Bangkok, Thailand', 'Y', 11);  -- 유저 11
INSERT INTO T_shipping_address VALUES (18, '565 Birch Street, Jakarta, Indonesia', 'Y', 12); -- 유저 12
INSERT INTO T_shipping_address VALUES (19, '676 Cedar Lane, Kuala Lumpur, Malaysia', 'N', 12); -- 유저 12
INSERT INTO T_shipping_address VALUES (20, '787 Cherry Way, Singapore', 'Y', 13);       -- 유저 13
INSERT INTO T_shipping_address VALUES (21, '898 Maple Path, Vienna, Austria', 'N', 14); -- 유저 14
INSERT INTO T_shipping_address VALUES (22, '909 Oak Terrace, Athens, Greece', 'Y', 14); -- 유저 14
INSERT INTO T_shipping_address VALUES (23, '101 Pine Blvd, Prague, Czech Republic', 'Y', 15); -- 유저 15
INSERT INTO T_shipping_address VALUES (24, '212 Willow Street, Warsaw, Poland', 'Y', 16); -- 유저 16
INSERT INTO T_shipping_address VALUES (25, '323 Elm Drive, Stockholm, Sweden', 'N', 17); -- 유저 17
INSERT INTO T_shipping_address VALUES (26, '434 Cedar Court, Copenhagen, Denmark', 'N', 17); -- 유저 17
INSERT INTO T_shipping_address VALUES (27, '545 Fir Lane, Oslo, Norway', 'Y', 17);     -- 유저 17
INSERT INTO T_shipping_address VALUES (28, '656 Maple Way, Helsinki, Finland', 'N', 17); -- 유저 17
INSERT INTO T_shipping_address VALUES (29, '767 Birch Street, Bucharest, Romania', 'Y', 18); -- 유저 18
INSERT INTO T_shipping_address VALUES (30, '878 Oak Avenue, Budapest, Hungary', 'N', 18); -- 유저 18
INSERT INTO T_shipping_address VALUES (31, '989 Pine Path, Lisbon, Portugal', 'Y', 19); -- 유저 19
INSERT INTO T_shipping_address VALUES (32, '100 Elm Drive, Dublin, Ireland', 'Y', 20);  -- 유저 20
INSERT INTO T_shipping_address VALUES (33, '111 Maple Terrace, San Francisco, USA', 'Y', 21); -- 유저 21
INSERT INTO T_shipping_address VALUES (34, '122 Willow Avenue, Los Angeles, USA', 'Y', 22); -- 유저 22
INSERT INTO T_shipping_address VALUES (35, '133 Oak Street, Chicago, USA', 'Y', 23);    -- 유저 23
INSERT INTO T_shipping_address VALUES (36, '144 Pine Court, Seattle, USA', 'N', 23);    -- 유저 23
INSERT INTO T_shipping_address VALUES (37, '155 Cedar Lane, Austin, USA', 'N', 23);    -- 유저 23
INSERT INTO T_shipping_address VALUES (38, '166 Birch Drive, Denver, USA', 'N', 24);    -- 유저 24
INSERT INTO T_shipping_address VALUES (39, '177 Cherry Path, Miami, USA', 'Y', 24);    -- 유저 24
INSERT INTO T_shipping_address VALUES (40, '188 Maple Street, Houston, USA', 'N', 25);  -- 유저 25
INSERT INTO T_shipping_address VALUES (41, '199 Oak Avenue, Toronto, Canada', 'Y', 25); -- 유저 25
INSERT INTO T_shipping_address VALUES (42, '200 Pine Lane, Vancouver, Canada', 'N', 25); -- 유저 25
INSERT INTO T_shipping_address VALUES (43, '211 Willow Drive, Montreal, Canada', 'N', 25); -- 유저 25
INSERT INTO T_shipping_address VALUES (44, '222 Elm Way, Calgary, Canada', 'Y', 26);     -- 유저 26
INSERT INTO T_shipping_address VALUES (45, '233 Cedar Court, Ottawa, Canada', 'Y', 27); -- 유저 27
INSERT INTO T_shipping_address VALUES (46, '244 Birch Avenue, Edmonton, Canada', 'Y', 28); -- 유저 28
INSERT INTO T_shipping_address VALUES (47, '255 Pine Drive, Quebec City, Canada', 'Y', 29); -- 유저 29
INSERT INTO T_shipping_address VALUES (48, '266 Maple Street, Winnipeg, Canada', 'N', 29); -- 유저 29
INSERT INTO T_shipping_address VALUES (49, '277 Oak Path, Halifax, Canada', 'Y', 30);   -- 유저 30
INSERT INTO T_shipping_address VALUES (50, '288 Willow Terrace, St. John''s, Canada', 'N', 30); -- 유저 30


-- 카테고리 데이터 삽입
INSERT INTO T_category VALUES(1, '컴퓨터·노트북', '');
INSERT INTO T_category VALUES(2, '노트북/데스크탑', 1);
INSERT INTO T_category VALUES(3, '입출력장치', 1);
INSERT INTO T_category VALUES(4, 'PC부품', 1);
INSERT INTO T_category VALUES(5, '게이밍 노트북', 2);
INSERT INTO T_category VALUES(6, '사무용 노트북', 2);
INSERT INTO T_category VALUES(7, '브랜드 PC', 2);
INSERT INTO T_category VALUES(8, 'AI/딥러닝 PC', 2);
INSERT INTO T_category VALUES(9, '모니터', 3);
INSERT INTO T_category VALUES(10, '키보드', 3);
INSERT INTO T_category VALUES(11, '마우스', 3);
INSERT INTO T_category VALUES(12, '웹캠', 3);
INSERT INTO T_category VALUES(13, '프린터', 3);
INSERT INTO T_category VALUES(14, 'CPU', 4);
INSERT INTO T_category VALUES(15, 'RAM', 4);
INSERT INTO T_category VALUES(16, 'SSD', 4);
INSERT INTO T_category VALUES(17, '가전·TV', '');
INSERT INTO T_category VALUES(18, '영상/음향가전', 17);
INSERT INTO T_category VALUES(19, '생활/계절가전', 17);
INSERT INTO T_category VALUES(20, '주방가전', 17);
INSERT INTO T_category VALUES(21, 'TV', 18);
INSERT INTO T_category VALUES(22, '프로젝터', 18);
INSERT INTO T_category VALUES(23, '셋톱박스', 18);
INSERT INTO T_category VALUES(24, '사운드바', 18);
INSERT INTO T_category VALUES(25, '앰프', 18);
INSERT INTO T_category VALUES(26, '세탁기', 19);
INSERT INTO T_category VALUES(27, '건조기', 19);
INSERT INTO T_category VALUES(28, '청소기', 19);
INSERT INTO T_category VALUES(29, '에어컨', 19);
INSERT INTO T_category VALUES(30, '냉장고', 20);
INSERT INTO T_category VALUES(31, '김치냉장고', 20);
INSERT INTO T_category VALUES(32, '전기밥솥', 20);
INSERT INTO T_category VALUES(33, '태블릿·모바일·게임', '');
INSERT INTO T_category VALUES(34, '태블릿/스마트폰', 33);
INSERT INTO T_category VALUES(35, '주변기기', 33);
INSERT INTO T_category VALUES(36, '게임기', 33);
INSERT INTO T_category VALUES(37, '삼성', 34);
INSERT INTO T_category VALUES(38, '애플', 34);
INSERT INTO T_category VALUES(39, '샤오미', 34);
INSERT INTO T_category VALUES(40, '스마트워치', 35);
INSERT INTO T_category VALUES(41, '모바일 악세서리', 35);
INSERT INTO T_category VALUES(42, '보조배터리', 35);
INSERT INTO T_category VALUES(43, '스위치', 36);
INSERT INTO T_category VALUES(44, '플레이스테이션', 36);
INSERT INTO T_category VALUES(45, '엑스박스', 36);


-- 상품 데이터 삽입
INSERT INTO T_product VALUES (1, 'Wireless Mouse', 25000, 100, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- 마우스 (입출력장치)
INSERT INTO T_product VALUES (2, 'Bluetooth Headphones', 75000, 50, 'http://example.com/images/tmp.jpg', SYSDATE, '', 18); -- 사운드바 (영상/음향가전)
INSERT INTO T_product VALUES (3, '4K Ultra HD Monitor', 320000, 20, 'http://example.com/images/tmp.jpg', SYSDATE, '', 9); -- 모니터 (입출력장치)
INSERT INTO T_product VALUES (4, 'Mechanical Keyboard', 120000, 75, 'http://example.com/images/tmp.jpg', SYSDATE, '', 10); -- 키보드 (입출력장치)
INSERT INTO T_product VALUES (5, 'Portable SSD 1TB', 150000, 30, 'http://example.com/images/tmp.jpg', SYSDATE, '', 16); -- SSD (PC부품)
INSERT INTO T_product VALUES (6, 'Gaming Mouse Pad', 15000, 150, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- 마우스 패드 (입출력장치)
INSERT INTO T_product VALUES (7, 'USB-C Hub', 40000, 60, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- USB 허브 (입출력장치)
INSERT INTO T_product VALUES (8, 'Smart Watch', 200000, 40, 'http://example.com/images/tmp.jpg', SYSDATE, '', 40); -- 스마트워치 (주변기기)
INSERT INTO T_product VALUES (9, 'Desk Lamp', 35000, 25, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (10, 'External Hard Drive 2TB', 180000, 15, 'http://example.com/images/tmp.jpg', SYSDATE, '', 16); -- 외장 하드 드라이브 (PC부품)
INSERT INTO T_product VALUES (11, 'Noise-Cancelling Headphones', 90000, 45, 'http://example.com/images/tmp.jpg', SYSDATE, '', 18); -- 사운드바 (영상/음향가전)
INSERT INTO T_product VALUES (12, 'Mechanical Gaming Keyboard', 130000, 65, 'http://example.com/images/tmp.jpg', SYSDATE, '', 10); -- 키보드 (입출력장치)
INSERT INTO T_product VALUES (13, 'Wireless Charging Pad', 30000, 80, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- 무선 충전 패드 (입출력장치)
INSERT INTO T_product VALUES (14, 'USB Flash Drive 64GB', 20000, 100, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- USB 플래시 드라이브 (입출력장치)
INSERT INTO T_product VALUES (15, 'Ergonomic Office Chair', 250000, 10, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (16, 'Bluetooth Speaker', 55000, 55, 'http://example.com/images/tmp.jpg', SYSDATE, '', 18); -- 스피커 (영상/음향가전)
INSERT INTO T_product VALUES (17, 'LED Monitor 27"', 220000, 25, 'http://example.com/images/tmp.jpg', SYSDATE, '', 9); -- 모니터 (입출력장치)
INSERT INTO T_product VALUES (18, 'Laptop Stand', 20000, 40, 'http://example.com/images/tmp.jpg', SYSDATE, '', 1); -- 노트북/데스크탑
INSERT INTO T_product VALUES (19, 'Cable Management Box', 12000, 70, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- 케이블 정리함 (입출력장치)
INSERT INTO T_product VALUES (20, 'Wi-Fi Router', 70000, 35, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (21, 'Webcam 1080p', 45000, 50, 'http://example.com/images/tmp.jpg', SYSDATE, '', 12); -- 웹캠 (입출력장치)
INSERT INTO T_product VALUES (22, 'Smartphone Stand', 15000, 90, 'http://example.com/images/tmp.jpg', SYSDATE, '', 34); -- 스마트폰 스탠드 (태블릿/스마트폰)
INSERT INTO T_product VALUES (23, 'Portable Projector', 300000, 20, 'http://example.com/images/tmp.jpg', SYSDATE, '', 22); -- 프로젝터 (영상/음향가전)
INSERT INTO T_product VALUES (24, 'Desk Organizer', 18000, 65, 'http://example.com/images/tmp.jpg', SYSDATE, '', 1); -- 노트북/데스크탑
INSERT INTO T_product VALUES (25, 'Mini Fridge', 150000, 30, 'http://example.com/images/tmp.jpg', SYSDATE, '', 20); -- 냉장고 (주방가전)
INSERT INTO T_product VALUES (26, 'Touchscreen Monitor', 250000, 15, 'http://example.com/images/tmp.jpg', SYSDATE, '', 9); -- 모니터 (입출력장치)
INSERT INTO T_product VALUES (27, 'Gaming Chair', 300000, 12, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (28, 'Smart Home Hub', 60000, 40, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 스마트 홈 허브 (생활/계절가전)
INSERT INTO T_product VALUES (29, '4K Action Camera', 180000, 25, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (30, 'Fitness Tracker', 50000, 50, 'http://example.com/images/tmp.jpg', SYSDATE, '', 40); -- 스마트워치 (주변기기)
INSERT INTO T_product VALUES (31, 'Digital Drawing Tablet', 220000, 18, 'http://example.com/images/tmp.jpg', SYSDATE, '', 33); -- 태블릿/스마트폰
INSERT INTO T_product VALUES (32, 'Cordless Drill', 140000, 22, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (33, 'Smart Thermostat', 80000, 28, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (34, 'Air Purifier', 120000, 15, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (35, 'Robotic Vacuum Cleaner', 250000, 10, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (36, 'HDMI Cable 2m', 12000, 60, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- HDMI 케이블 (입출력장치)
INSERT INTO T_product VALUES (37, 'Electric Kettle', 30000, 40, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전
INSERT INTO T_product VALUES (38, 'Bluetooth Keyboard', 40000, 75, 'http://example.com/images/tmp.jpg', SYSDATE, '', 10); -- 키보드 (입출력장치)
INSERT INTO T_product VALUES (39, 'Surge Protector', 15000, 55, 'http://example.com/images/tmp.jpg', SYSDATE, '', 11); -- 서지 프로텍터 (입출력장치)
INSERT INTO T_product VALUES (40, 'Digital Camera', 250000, 20, 'http://example.com/images/tmp.jpg', SYSDATE, '', 17); -- 생활/계절가전


-- 주문 데이터 삽입
INSERT INTO T_order VALUES (1, 'John Doe', '01012345678', '1234 Elm Street, Springfield, IL, USA', '발송대기', SYSDATE, NULL, 15);
INSERT INTO T_order VALUES (2, 'Jane Smith', '01023456789', '56 Avenue des Champs-Élysées, Paris, France', '배송중', SYSDATE - 2, NULL, 22);
INSERT INTO T_order VALUES (3, 'Kumar Patel', '01034567890', 'Flat 5B, 3rd Cross, Bangalore, India', '배송완료', SYSDATE - 5, SYSDATE - 1, 7);
INSERT INTO T_order VALUES (4, 'Maria Garcia', '01045678901', 'Rua das Flores, 234, Lisbon, Portugal', '주문취소', SYSDATE - 3, NULL, 29);
INSERT INTO T_order VALUES (5, 'Liam O''Connor', '01056789012', '101 Queen Street, Auckland, New Zealand', '발송대기', SYSDATE - 1, NULL, 13);
INSERT INTO T_order VALUES (6, 'Aisha Khan', '01067890123', '456 Main Road, Cairo, Egypt', '배송중', SYSDATE - 4, NULL, 3);
INSERT INTO T_order VALUES (7, 'Lucas Müller', '01078901234', '789 Königstraße, Berlin, Germany', '배송완료', SYSDATE - 6, SYSDATE - 2, 8);
INSERT INTO T_order VALUES (8, 'Sofia Rossi', '01089012345', '12 Via del Corso, Rome, Italy', '주문취소', SYSDATE - 2, NULL, 18);
INSERT INTO T_order VALUES (9, 'Jin Park', '01090123456', '34-2, Gangnam-gu, Seoul, South Korea', '발송대기', SYSDATE - 3, NULL, 9);
INSERT INTO T_order VALUES (10, 'Emma Johnson', '01001234567', '101 Oxford Street, London, UK', '배송중', SYSDATE - 7, NULL, 25);
INSERT INTO T_order VALUES (11, 'Carlos Sánchez', '01012345679', '678 Avenida de América, Madrid, Spain', '배송완료', SYSDATE - 8, SYSDATE - 3, 5);
INSERT INTO T_order VALUES (12, 'Olivia Martinez', '01023456780', '1234 King Street, Toronto, Canada', '주문취소', SYSDATE - 4, NULL, 6);
INSERT INTO T_order VALUES (13, 'Noah Brown', '01034567891', '89 Jalan Raya, Jakarta, Indonesia', '발송대기', SYSDATE - 2, NULL, 17);
INSERT INTO T_order VALUES (14, 'Lily Wilson', '01045678902', '67 Rua da Consolação, São Paulo, Brazil', '배송중', SYSDATE - 5, NULL, 20);
INSERT INTO T_order VALUES (15, 'Mia Lee', '01056789023', '43-2, Nanjing Road, Shanghai, China', '배송완료', SYSDATE - 10, SYSDATE - 4, 12);
INSERT INTO T_order VALUES (16, 'Ethan Wang', '01067890134', '987 Nanjing East Road, Taipei, Taiwan', '주문취소', SYSDATE - 6, NULL, 21);
INSERT INTO T_order VALUES (17, 'Aria Smith', '01078901245', '12 Queen Street, Sydney, Australia', '발송대기', SYSDATE - 1, NULL, 26);
INSERT INTO T_order VALUES (18, 'Oliver Scott', '01089012356', '23 Roppongi, Tokyo, Japan', '배송중', SYSDATE - 8, NULL, 19);
INSERT INTO T_order VALUES (19, 'Isabella Garcia', '01090123467', '45 Fifth Avenue, New York, USA', '배송완료', SYSDATE - 9, SYSDATE - 5, 2);
INSERT INTO T_order VALUES (20, 'William Green', '01001234578', '123 Rue de Rivoli, Paris, France', '주문취소', SYSDATE - 2, NULL, 14);
INSERT INTO T_order VALUES (21, 'Sophia Lee', '01012345680', '789 Bourbon Street, New Orleans, USA', '발송대기', SYSDATE - 4, NULL, 30);
INSERT INTO T_order VALUES (22, 'James Wilson', '01023456781', '456 Pritchard Road, Auckland, New Zealand', '배송중', SYSDATE - 6, NULL, 23);
INSERT INTO T_order VALUES (23, 'Emma Williams', '01034567892', '32 Schillerstraße, Munich, Germany', '배송완료', SYSDATE - 7, SYSDATE - 2, 27);
INSERT INTO T_order VALUES (24, 'Benjamin Brown', '01045678903', '67 Gran Via, Barcelona, Spain', '주문취소', SYSDATE - 3, NULL, 4);
INSERT INTO T_order VALUES (25, 'Mia Taylor', '01056789034', '1230 George Street, Sydney, Australia', '발송대기', SYSDATE - 5, NULL, 10);
INSERT INTO T_order VALUES (26, 'Lucas Martin', '01067890145', '432 High Street, London, UK', '배송중', SYSDATE - 7, NULL, 11);
INSERT INTO T_order VALUES (27, 'Chloe Anderson', '01078901256', '9 Rue du Faubourg Saint-Honoré, Paris, France', '배송완료', SYSDATE - 9, SYSDATE - 3, 16);
INSERT INTO T_order VALUES (28, 'Ethan Thomas', '01089012367', '567 Canal Street, New York, USA', '주문취소', SYSDATE - 4, NULL, 28);
INSERT INTO T_order VALUES (29, 'Harper Jackson', '01090123478', '1234 Queen Street, Toronto, Canada', '발송대기', SYSDATE - 2, NULL, 24);
INSERT INTO T_order VALUES (30, 'Liam Garcia', '01001234579', '789 George Street, Sydney, Australia', '배송중', SYSDATE - 6, NULL, 30);
INSERT INTO T_order VALUES (31, 'Ava Rodriguez', '01012345681', '2345 Main Street, Los Angeles, USA', '배송완료', SYSDATE - 8, SYSDATE - 4, 22);
INSERT INTO T_order VALUES (32, 'Mason Lee', '01023456782', '345 Orchard Road, Singapore', '주문취소', SYSDATE - 3, NULL, 13);
INSERT INTO T_order VALUES (33, 'Sophie Martin', '01034567893', '789 Deansgate, Manchester, UK', '발송대기', SYSDATE - 1, NULL, 6);
INSERT INTO T_order VALUES (34, 'Logan White', '01045678904', '12 Bay Street, Sydney, Australia', '배송중', SYSDATE - 5, NULL, 9);
INSERT INTO T_order VALUES (35, 'Mia Thompson', '01056789045', '345 Yonge Street, Toronto, Canada', '배송완료', SYSDATE - 7, SYSDATE - 2, 15);
INSERT INTO T_order VALUES (36, 'Ella Hall', '01067890156', '789 Ratchadamri Road, Bangkok, Thailand', '주문취소', SYSDATE - 4, NULL, 20);
INSERT INTO T_order VALUES (37, 'Noah Robinson', '01078901267', '23 Raffles Place, Singapore', '발송대기', SYSDATE - 2, NULL, 12);
INSERT INTO T_order VALUES (38, 'Avery Johnson', '01089012378', '456 Queen Street, Melbourne, Australia', '배송중', SYSDATE - 6, NULL, 18);
INSERT INTO T_order VALUES (39, 'Jackson Clark', '01090123489', '12 Wall Street, New York, USA', '배송완료', SYSDATE - 9, SYSDATE - 3, 7);
INSERT INTO T_order VALUES (40, 'Zoe Davis', '01001234580', '789 Rue du Bac, Paris, France', '주문취소', SYSDATE - 5, NULL, 8);
INSERT INTO T_order VALUES (41, 'Mia Lewis', '01012345682', '567 Orchard Road, Singapore', '발송대기', SYSDATE - 1, NULL, 16);
INSERT INTO T_order VALUES (42, 'Oliver King', '01023456783', '123 Bond Street, London, UK', '배송중', SYSDATE - 4, NULL, 25);
INSERT INTO T_order VALUES (43, 'Harper Wright', '01034567894', '78 Kings Road, Melbourne, Australia', '배송완료', SYSDATE - 7, SYSDATE - 3, 21);
INSERT INTO T_order VALUES (44, 'Benjamin Miller', '01045678905', '234 Oxford Street, London, UK', '주문취소', SYSDATE - 2, NULL, 28);
INSERT INTO T_order VALUES (45, 'Evelyn Nelson', '01056789056', '345 King''s Road, Hong Kong', '발송대기', SYSDATE - 3, NULL, 30);
INSERT INTO T_order VALUES (46, 'Jackson Young', '01067890167', '456 High Street, Dublin, Ireland', '배송중', SYSDATE - 6, NULL, 11);
INSERT INTO T_order VALUES (47, 'Aria Scott', '01078901278', '12 Bond Street, New York, USA', '배송완료', SYSDATE - 8, SYSDATE - 4, 19);
INSERT INTO T_order VALUES (48, 'Eli Adams', '01089012389', '34 Leopold Street, Johannesburg, South Africa', '주문취소', SYSDATE - 2, NULL, 24);
INSERT INTO T_order VALUES (49, 'Amelia Baker', '01090123490', '1230 Newbury Street, Boston, USA', '발송대기', SYSDATE - 1, NULL, 9);
INSERT INTO T_order VALUES (50, 'Mason Carter', '01001234581', '567 Port Road, Perth, Australia', '배송중', SYSDATE - 5, NULL, 5);


-- OrderedProduct 데이터 삽입
INSERT INTO T_ordered_product VALUES (1, 3, 1, 5);  -- 주문 ID 1에서 제품 ID 5를 3개 주문
INSERT INTO T_ordered_product VALUES (2, 2, 1, 12); -- 주문 ID 1에서 제품 ID 12를 2개 주문
INSERT INTO T_ordered_product VALUES (3, 10, 1, 20); -- 주문 ID 1에서 제품 ID 20을 10개 주문
INSERT INTO T_ordered_product VALUES (4, 4, 1, 8);  -- 주문 ID 1에서 제품 ID 8을 4개 주문
INSERT INTO T_ordered_product VALUES (5, 5, 1, 25); -- 주문 ID 1에서 제품 ID 25를 5개 주문
INSERT INTO T_ordered_product VALUES (6, 2, 1, 14); -- 주문 ID 1에서 제품 ID 14를 2개 주문
INSERT INTO T_ordered_product VALUES (7, 3, 2, 30); -- 주문 ID 2에서 제품 ID 30을 3개 주문
INSERT INTO T_ordered_product VALUES (8, 1, 3, 11); -- 주문 ID 3에서 제품 ID 11을 1개 주문
INSERT INTO T_ordered_product VALUES (9, 6, 3, 22); -- 주문 ID 3에서 제품 ID 22를 6개 주문
INSERT INTO T_ordered_product VALUES (10, 4, 3, 7); -- 주문 ID 3에서 제품 ID 7을 4개 주문
INSERT INTO T_ordered_product VALUES (11, 5, 3, 13);-- 주문 ID 3에서 제품 ID 13을 5개 주문
INSERT INTO T_ordered_product VALUES (12, 2, 3, 9); -- 주문 ID 3에서 제품 ID 9를 2개 주문
INSERT INTO T_ordered_product VALUES (13, 3, 3, 28);-- 주문 ID 3에서 제품 ID 28을 3개 주문
INSERT INTO T_ordered_product VALUES (14, 4, 3, 15);-- 주문 ID 3에서 제품 ID 15를 4개 주문
INSERT INTO T_ordered_product VALUES (15, 11, 4, 18);-- 주문 ID 4에서 제품 ID 18을 11개 주문
INSERT INTO T_ordered_product VALUES (16, 6, 4, 10);-- 주문 ID 4에서 제품 ID 10을 6개 주문
INSERT INTO T_ordered_product VALUES (17, 2, 4, 21);-- 주문 ID 4에서 제품 ID 21을 2개 주문
INSERT INTO T_ordered_product VALUES (18, 3, 5, 3); -- 주문 ID 5에서 제품 ID 3를 3개 주문
INSERT INTO T_ordered_product VALUES (19, 7, 5, 16);-- 주문 ID 5에서 제품 ID 16을 7개 주문
INSERT INTO T_ordered_product VALUES (20, 1, 5, 4);-- 주문 ID 5에서 제품 ID 4를 1개 주문
INSERT INTO T_ordered_product VALUES (21, 5, 6, 27); -- 주문 ID 6에서 제품 ID 27을 5개 주문
INSERT INTO T_ordered_product VALUES (22, 4, 6, 6);-- 주문 ID 6에서 제품 ID 6을 4개 주문
INSERT INTO T_ordered_product VALUES (23, 3, 6, 23); -- 주문 ID 6에서 제품 ID 23을 3개 주문
INSERT INTO T_ordered_product VALUES (24, 20, 6, 19); -- 주문 ID 6에서 제품 ID 19를 20개 주문
INSERT INTO T_ordered_product VALUES (25, 6, 6, 31); -- 주문 ID 6에서 제품 ID 31을 6개 주문
INSERT INTO T_ordered_product VALUES (26, 12, 6, 2);-- 주문 ID 6에서 제품 ID 2를 12개 주문
INSERT INTO T_ordered_product VALUES (27, 7, 6, 26); -- 주문 ID 6에서 제품 ID 26을 7개 주문
INSERT INTO T_ordered_product VALUES (28, 4, 6, 24); -- 주문 ID 6에서 제품 ID 24를 4개 주문
INSERT INTO T_ordered_product VALUES (29, 2, 6, 29); -- 주문 ID 6에서 제품 ID 29를 2개 주문
INSERT INTO T_ordered_product VALUES (30, 5, 7, 17); -- 주문 ID 7에서 제품 ID 17을 5개 주문
INSERT INTO T_ordered_product VALUES (31, 3, 8, 32); -- 주문 ID 8에서 제품 ID 32를 3개 주문
INSERT INTO T_ordered_product VALUES (32, 6, 9, 1);-- 주문 ID 9에서 제품 ID 1을 6개 주문
INSERT INTO T_ordered_product VALUES (33, 4, 10, 33); -- 주문 ID 10에서 제품 ID 33을 4개 주문
INSERT INTO T_ordered_product VALUES (34, 2, 10, 34); -- 주문 ID 10에서 제품 ID 34를 2개 주문
INSERT INTO T_ordered_product VALUES (35, 5, 10, 35); -- 주문 ID 10에서 제품 ID 35를 5개 주문
INSERT INTO T_ordered_product VALUES (36, 3, 10, 36); -- 주문 ID 10에서 제품 ID 36을 3개 주문
INSERT INTO T_ordered_product VALUES (37, 4, 10, 37); -- 주문 ID 10에서 제품 ID 37을 4개 주문
INSERT INTO T_ordered_product VALUES (38, 2, 10, 38); -- 주문 ID 10에서 제품 ID 38을 2개 주문
INSERT INTO T_ordered_product VALUES (39, 6, 10, 39); -- 주문 ID 10에서 제품 ID 39를 6개 주문
INSERT INTO T_ordered_product VALUES (40, 5, 10, 40); -- 주문 ID 10에서 제품 ID 40을 5개 주문
INSERT INTO T_ordered_product VALUES (41, 3, 10, 22); -- 주문 ID 10에서 제품 ID 22를 3개 주문
INSERT INTO T_ordered_product VALUES (42, 2, 11, 23); -- 주문 ID 11에서 제품 ID 23을 2개 주문
INSERT INTO T_ordered_product VALUES (43, 4, 11, 24); -- 주문 ID 11에서 제품 ID 24를 4개 주문
INSERT INTO T_ordered_product VALUES (44, 6, 11, 25); -- 주문 ID 11에서 제품 ID 25를 6개 주문
INSERT INTO T_ordered_product VALUES (45, 5, 11, 26); -- 주문 ID 11에서 제품 ID 26을 5개 주문
INSERT INTO T_ordered_product VALUES (46, 2, 11, 27); -- 주문 ID 11에서 제품 ID 27을 2개 주문
INSERT INTO T_ordered_product VALUES (47, 3, 12, 28); -- 주문 ID 12에서 제품 ID 28을 3개 주문
INSERT INTO T_ordered_product VALUES (48, 7, 12, 29); -- 주문 ID 12에서 제품 ID 29를 7개 주문
INSERT INTO T_ordered_product VALUES (49, 13, 13, 30); -- 주문 ID 13에서 제품 ID 30을 13개 주문
INSERT INTO T_ordered_product VALUES (50, 5, 13, 31); -- 주문 ID 13에서 제품 ID 31을 5개 주문
INSERT INTO T_ordered_product VALUES (51, 3, 14, 6);  -- 주문 ID 14에서 제품 ID 6을 3개 주문
INSERT INTO T_ordered_product VALUES (52, 4, 14, 19); -- 주문 ID 14에서 제품 ID 19를 4개 주문
INSERT INTO T_ordered_product VALUES (53, 2, 14, 13); -- 주문 ID 14에서 제품 ID 13을 2개 주문
INSERT INTO T_ordered_product VALUES (54, 5, 14, 9);  -- 주문 ID 14에서 제품 ID 9를 5개 주문
INSERT INTO T_ordered_product VALUES (55, 3, 14, 15); -- 주문 ID 14에서 제품 ID 15를 3개 주문
INSERT INTO T_ordered_product VALUES (56, 1, 14, 22); -- 주문 ID 14에서 제품 ID 22를 1개 주문
INSERT INTO T_ordered_product VALUES (57, 6, 17, 18); -- 주문 ID 17에서 제품 ID 18을 6개 주문
INSERT INTO T_ordered_product VALUES (58, 4, 17, 34); -- 주문 ID 17에서 제품 ID 34를 4개 주문
INSERT INTO T_ordered_product VALUES (59, 2, 17, 10); -- 주문 ID 17에서 제품 ID 10을 2개 주문
INSERT INTO T_ordered_product VALUES (60, 7, 17, 20); -- 주문 ID 17에서 제품 ID 20을 7개 주문
INSERT INTO T_ordered_product VALUES (61, 3, 17, 12); -- 주문 ID 17에서 제품 ID 12를 3개 주문
INSERT INTO T_ordered_product VALUES (62, 5, 17, 27); -- 주문 ID 17에서 제품 ID 27을 5개 주문
INSERT INTO T_ordered_product VALUES (63, 4, 17, 7);  -- 주문 ID 17에서 제품 ID 7을 4개 주문
INSERT INTO T_ordered_product VALUES (64, 2, 18, 28); -- 주문 ID 18에서 제품 ID 28을 2개 주문
INSERT INTO T_ordered_product VALUES (65, 6, 18, 5);  -- 주문 ID 18에서 제품 ID 5를 6개 주문
INSERT INTO T_ordered_product VALUES (66, 1, 19, 31); -- 주문 ID 19에서 제품 ID 31을 1개 주문
INSERT INTO T_ordered_product VALUES (67, 3, 20, 24); -- 주문 ID 20에서 제품 ID 24를 3개 주문
INSERT INTO T_ordered_product VALUES (68, 7, 20, 26); -- 주문 ID 20에서 제품 ID 26을 7개 주문
INSERT INTO T_ordered_product VALUES (69, 2, 20, 30);-- 주문 ID 20에서 제품 ID 30을 2개 주문
INSERT INTO T_ordered_product VALUES (70, 4, 21, 36);-- 주문 ID 21에서 제품 ID 36을 4개 주문
INSERT INTO T_ordered_product VALUES (71, 3, 22, 11);-- 주문 ID 22에서 제품 ID 11을 3개 주문
INSERT INTO T_ordered_product VALUES (72, 6, 23, 21);-- 주문 ID 23에서 제품 ID 21을 6개 주문
INSERT INTO T_ordered_product VALUES (73, 5, 24, 13);-- 주문 ID 24에서 제품 ID 13을 5개 주문
INSERT INTO T_ordered_product VALUES (74, 2, 25, 35);-- 주문 ID 25에서 제품 ID 35를 2개 주문
INSERT INTO T_ordered_product VALUES (75, 4, 25, 17);-- 주문 ID 25에서 제품 ID 17을 4개 주문
INSERT INTO T_ordered_product VALUES (76, 16, 26, 39);-- 주문 ID 26에서 제품 ID 39를 16개 주문
INSERT INTO T_ordered_product VALUES (77, 7, 27, 14);-- 주문 ID 27에서 제품 ID 14를 7개 주문
INSERT INTO T_ordered_product VALUES (78, 3, 27, 25);-- 주문 ID 27에서 제품 ID 25를 3개 주문
INSERT INTO T_ordered_product VALUES (79, 6, 27, 8); -- 주문 ID 27에서 제품 ID 8을 6개 주문
INSERT INTO T_ordered_product VALUES (80, 4, 27, 23);-- 주문 ID 27에서 제품 ID 23을 4개 주문
INSERT INTO T_ordered_product VALUES (81, 2, 28, 2); -- 주문 ID 28에서 제품 ID 2를 2개 주문
INSERT INTO T_ordered_product VALUES (82, 5, 28, 26);-- 주문 ID 28에서 제품 ID 26을 5개 주문
INSERT INTO T_ordered_product VALUES (83, 3, 29, 3); -- 주문 ID 29에서 제품 ID 3을 3개 주문
INSERT INTO T_ordered_product VALUES (84, 4, 30, 4); -- 주문 ID 30에서 제품 ID 4를 4개 주문
INSERT INTO T_ordered_product VALUES (85, 6, 30, 7); -- 주문 ID 30에서 제품 ID 7을 6개 주문
INSERT INTO T_ordered_product VALUES (86, 2, 30, 20);-- 주문 ID 30에서 제품 ID 20을 2개 주문
INSERT INTO T_ordered_product VALUES (87, 7, 30, 9); -- 주문 ID 30에서 제품 ID 9을 7개 주문
INSERT INTO T_ordered_product VALUES (88, 5, 30, 12);-- 주문 ID 30에서 제품 ID 12를 5개 주문
INSERT INTO T_ordered_product VALUES (89, 4, 30, 6); -- 주문 ID 30에서 제품 ID 6을 4개 주문
INSERT INTO T_ordered_product VALUES (90, 3, 31, 33);-- 주문 ID 31에서 제품 ID 33을 3개 주문
INSERT INTO T_ordered_product VALUES (91, 2, 31, 19);-- 주문 ID 31에서 제품 ID 19를 2개 주문
INSERT INTO T_ordered_product VALUES (92, 6, 32, 25);-- 주문 ID 32에서 제품 ID 25를 6개 주문
INSERT INTO T_ordered_product VALUES (93, 7, 32, 11);-- 주문 ID 32에서 제품 ID 11을 7개 주문
INSERT INTO T_ordered_product VALUES (94, 3, 33, 32);-- 주문 ID 33에서 제품 ID 32를 3개 주문
INSERT INTO T_ordered_product VALUES (95, 4, 34, 28);-- 주문 ID 34에서 제품 ID 28을 4개 주문
INSERT INTO T_ordered_product VALUES (96, 5, 34, 30);-- 주문 ID 34에서 제품 ID 30을 5개 주문
INSERT INTO T_ordered_product VALUES (97, 2, 34, 18);-- 주문 ID 34에서 제품 ID 18을 2개 주문
INSERT INTO T_ordered_product VALUES (98, 6, 35, 40);-- 주문 ID 35에서 제품 ID 40을 6개 주문
INSERT INTO T_ordered_product VALUES (99, 3, 35, 8); -- 주문 ID 35에서 제품 ID 8을 3개 주문
INSERT INTO T_ordered_product VALUES (100, 7, 35, 37); -- 주문 ID 35에서 제품 ID 37을 7개 주문


-- 카트 데이터 삽입
INSERT INTO T_cart VALUES (1, 3, 12, 25);
INSERT INTO T_cart VALUES (2, 1, 8, 33);
INSERT INTO T_cart VALUES (3, 4, 1, 7);
INSERT INTO T_cart VALUES (4, 2, 29, 19);
INSERT INTO T_cart VALUES (5, 5, 1, 40);
INSERT INTO T_cart VALUES (6, 3, 18, 11);
INSERT INTO T_cart VALUES (7, 1, 7, 5);
INSERT INTO T_cart VALUES (8, 2, 20, 27);
INSERT INTO T_cart VALUES (9, 4, 9, 38);
INSERT INTO T_cart VALUES (10, 3, 6, 14);
INSERT INTO T_cart VALUES (11, 2, 2, 9);
INSERT INTO T_cart VALUES (12, 1, 30, 22);
INSERT INTO T_cart VALUES (13, 5, 13, 31);
INSERT INTO T_cart VALUES (14, 4, 10, 8);
INSERT INTO T_cart VALUES (15, 3, 16, 35);
INSERT INTO T_cart VALUES (16, 2, 30, 20);
INSERT INTO T_cart VALUES (17, 4, 27, 18);
INSERT INTO T_cart VALUES (18, 1, 10, 24);
INSERT INTO T_cart VALUES (19, 3, 23, 40);
INSERT INTO T_cart VALUES (20, 5, 4, 2);
INSERT INTO T_cart VALUES (21, 2, 28, 15);
INSERT INTO T_cart VALUES (22, 1, 17, 29);
INSERT INTO T_cart VALUES (23, 4, 12, 32);
INSERT INTO T_cart VALUES (24, 3, 5, 10);
INSERT INTO T_cart VALUES (25, 2, 2, 36);
INSERT INTO T_cart VALUES (26, 5, 14, 1);
INSERT INTO T_cart VALUES (27, 1, 2, 7);
INSERT INTO T_cart VALUES (28, 4, 2, 28);
INSERT INTO T_cart VALUES (29, 3, 29, 23);
INSERT INTO T_cart VALUES (30, 2, 29, 39);


-- 어드민 데이터 삽입
INSERT INTO T_admin VALUES (1, 'africanelephant', 'P@ssw0rd123!', 'African Elephant', 'africanelephant@example.com', '01012345678', SYSDATE, SYSDATE, '10.0.0.1');
INSERT INTO T_admin VALUES (2, 'giraffe', 'SecureP@ss2024', 'Giraffe', 'giraffe@example.com', '01023456789', SYSDATE, SYSDATE, '10.0.0.2');
INSERT INTO T_admin VALUES (3, 'hippopotamus', 'M1cha3l!2024', 'Hippopotamus', 'hippopotamus@example.com', '01034567890', SYSDATE, SYSDATE, '10.0.0.3');
INSERT INTO T_admin VALUES (4, 'komododragon', 'Br0wnP@ssw0rd', 'Komodo Dragon', 'komododragon@example.com', '01045678901', SYSDATE, SYSDATE, '10.0.0.4');
INSERT INTO T_admin VALUES (5, 'beaver', 'W1ls0n#2024', 'North American Beaver', 'beaver@example.com', '01056789012', SYSDATE, SYSDATE, '10.0.0.5');
INSERT INTO T_admin VALUES (6, 'americanelm', 'T@yloR2024!', 'American Elm Tree', 'americanelm@example.com', '01067890123', SYSDATE, SYSDATE, '10.0.0.6');
INSERT INTO T_admin VALUES (7, 'californiaredwood', 'D@ni3l#2024', 'California Redwood', 'californiaredwood@example.com', '01078901234', SYSDATE, SYSDATE, '10.0.0.7');
INSERT INTO T_admin VALUES (8, 'japanesemaple', '0l1v1@2024!', 'Japanese Maple Tree', 'japanesemaple@example.com', '01089012345', SYSDATE, SYSDATE, '10.0.0.8');
INSERT INTO T_admin VALUES (9, 'southernmagnolia', 'R1ch@rd2024!', 'Southern Magnolia', 'southernmagnolia@example.com', '01090123456', SYSDATE, SYSDATE, '10.0.0.9');
INSERT INTO T_admin VALUES (10, 'europeanoak', 'L1nd@W!2024', 'European Oak Tree', 'europeanoak@example.com', '01001234567', SYSDATE, SYSDATE, '10.0.0.10');
